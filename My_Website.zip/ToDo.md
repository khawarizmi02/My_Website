## Semua Page

### Footer

- Make sure semua format sama lebar

## Home Page

### First Section

- Buang Gambar list pindah kat bawah
- Buat Background pakai gambar dari Studio
- Pindah About Us dari about us section ke intro
- Bagi Access untuk content about us

### New Section (below First Section)

- Buat list gambar macam dari first section
- Bagi Access untuk buat list gambar unutk second section
- bagi access unutk upload video (optional)

### Second Section (Why Titan Pest Solution)

- Bagi Access untuk ubah content
- tukar logo dengan image upload dari studio

### Third Section (About Us & YOUR RELIABLE PEST CONTROL OPERATOR)

- Buang this section

### Last Section (Request Free Quotation)

- Ubah design Form kasi lagi jelas

## About Page

### Value Part

- Buat value list sebagai single entity
- buat list value

### Certificates and Accrediation

- Adjust Gambar certificates
